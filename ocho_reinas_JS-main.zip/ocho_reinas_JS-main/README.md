Programa del problema de las ocho reinas.
