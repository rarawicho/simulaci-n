var reinasPorColocar = 8;
var reinasColocadas = 0;

function colocarReina(celda){
    /*alert("Le dieron click a la celda"+celda);*/
    
    if (window.getComputedStyle(celda).backgroundImage == "none") {
      if (reinasColocadas < 8) {
      celda.style = "background-image: url(./img/reina.png); background-size:cover;";
      var renglon = celda.parentElement.rowIndex;
      var columna = celda.cellIndex;
      alert(renglon + " " + columna);

      reinasPorColocar--;
      reinasColocadas++;
    }
    } else {
      celda.style = "background-image: none";
      reinasPorColocar++;
      reinasColocadas--;
    }
    document.getElementById("reinasColoca").innerHTML="Reinas por colocar: "+reinasPorColocar;
    document.getElementById("reinasColoca1").innerHTML="Reinas Colocadas: " + reinasColocadas;
  
}